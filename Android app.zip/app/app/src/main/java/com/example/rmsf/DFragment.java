package com.example.rmsf;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.support.v4.app.DialogFragment;


    public class DFragment extends DialogFragment {
        public static DFragment newInstance(String message) {
            DFragment dFragment = new DFragment();
            Bundle args = new Bundle();
            args.putString("message", message);
            dFragment.setArguments(args);
            return dFragment;
        }

        @Override
        public Dialog onCreateDialog(Bundle savedInstanceState) {
            String message = getArguments().getString("message");

            return new AlertDialog.Builder(getActivity())
                    //.setTitle("Error message")
                    // Set Dialog Message
                    .setMessage(message)

                    // Negative Button
                    .setNegativeButton("OK", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog,	int which) {
                            getDialog().dismiss();
                        }
                    }).create();
        }
    }

