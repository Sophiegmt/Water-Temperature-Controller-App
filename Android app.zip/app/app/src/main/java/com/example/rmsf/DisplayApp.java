package com.example.rmsf;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;

public class DisplayApp extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_display_app);

    }

    public String getUsername(){
        String username="";
        username = getIntent().getStringExtra("username");
        return username;
    }

    public void gotoGraph(View view) {
        // Do something in response to button
        Intent intent = new Intent(this, GraphActivity.class);
        intent.putExtra("username", getUsername());  // juntar a string
        startActivity(intent);
    }

    public void gotoSettings(View view) {
        // Do something in response to button
        Intent intent = new Intent(this, SettingsActivity.class);
        intent.putExtra("username", getUsername());  // juntar a string
        startActivity(intent);
    }


    public void gotoPassword(View view) {
        // Do something in response to button
        Intent intent = new Intent(this, ChangePassword.class);
        intent.putExtra("username", getUsername());  // juntar a string
        startActivity(intent);
    }

}
