package com.example.rmsf;

import android.graphics.Color;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.app.FragmentManager;
import android.support.v7.app.AppCompatActivity;

import com.jjoe64.graphview.GraphView;
import com.jjoe64.graphview.series.DataPoint;
import com.jjoe64.graphview.series.LineGraphSeries;

import org.json.JSONArray;
import org.json.JSONException;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;


public class GraphActivity extends AppCompatActivity {
    FragmentManager fm = getSupportFragmentManager();
    LineGraphSeries<DataPoint> series;

    private GraphView graph;
    double x;
    double y;
    String [] TempGraph;
    int [] results;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.graphview);

        graph = findViewById(R.id.graph);
        x = 0;
        y = 0;

        new GraphActivity.askTempsToServer().execute();



        series = new LineGraphSeries<DataPoint>();
        series.setColor(Color.BLUE);
        series.setThickness(2);


    }

    public String getUsername(){
        String username="";
        username = getIntent().getStringExtra("username");
        return username;
    }


    private void setupAxes(int max) {
        graph.setTitle("Registo de Temperaturas");
        graph.getGridLabelRenderer().setVerticalAxisTitle("Temperature Value (ºC)");
        graph.getGridLabelRenderer().setHorizontalAxisTitle("Time (s)");
        if(max-50>0)
            graph.getViewport().setMinX(max-50);
        else
            graph.getViewport().setMinX(0);
        graph.getViewport().setMinY(0);
        graph.getViewport().setMaxY(40);
        graph.getViewport().setYAxisBoundsManual(true);
        graph.getViewport().setXAxisBoundsManual(true);
    }


    public class askTempsToServer extends AsyncTask<String, String, String> {

            @Override
            protected String doInBackground(String... arg0) {

                try {
                    String username = getUsername();
                    String link = "http://web.ist.utl.pt/~ist425319/getTs.php?username=" + username;
                    URL url = new URL(link);

                    HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();
                    urlConnection.setRequestMethod("GET");
                    urlConnection.connect();

                    InputStream response = urlConnection.getInputStream();
                    String TempArray = getTempFromResponse(response);
                    int i = 0;


                    TempGraph=TempArray.split(",");
                    int max=TempGraph.length;

                    results= new int[max];

                    for(i=0;i<max;i++)
                        results[i]=0;

                    System.out.println(TempArray);
                    System.out.println(max);

                    i=0;
                    while (i < max)
                    {
                        results[i]=Integer.parseInt(TempGraph[i]);
                        i++;
                    }

                    for(i=0; i< max; i++) {
                        y = results[i];
                        x = i;
                        series.appendData(new DataPoint(x, y), true, max);
                    }

                    graph.addSeries(series);
                    graph.getViewport().setMaxX(max);
                    setupAxes(max);

                    urlConnection.disconnect();

                } catch (IOException e) {
                    e.printStackTrace();

                } catch (JSONException e) {
                    e.printStackTrace();
                }
                    return "Ok";
                }
        }

    public String getTempFromResponse (InputStream is) throws JSONException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(is));
        StringBuilder sb = new StringBuilder();

        String line = null;
        try {
            while ((line = reader.readLine()) != null) {
                sb.append(line);
            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                is.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        JSONArray json = new JSONArray(sb.toString());

        String whatToPrint = "";
        for (int i = 0; i < json.length(); i++) {
            if (!whatToPrint.isEmpty()) {
                whatToPrint = whatToPrint+ ',';
            }
            whatToPrint = whatToPrint + json.getString(i);

        }

        return whatToPrint;
    }

}
