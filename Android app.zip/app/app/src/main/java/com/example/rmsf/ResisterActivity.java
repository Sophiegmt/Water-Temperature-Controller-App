package com.example.rmsf;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.EditText;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class ResisterActivity extends AppCompatActivity {
    String error = "";
    Boolean go = false;
    JSONObject json = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
    }

    public void register(View view) {

        //GET WHAT WAS WRITTEN BY THE USER
        EditText usernameFromUser2 = findViewById(R.id.username);
        EditText passwordFromUser2 =  findViewById(R.id.password2);
        EditText minTempFromUser2 = findViewById(R.id.minTemp);
        EditText maxTempFromUser2 =  findViewById(R.id.maxTemp);
        EditText WBstatusFromUser2 =  findViewById(R.id.WBstatus);

        //FILTER THE WRITTEN TEXT FROM USER
        String username = usernameFromUser2.getText().toString();
        username = username.replaceAll(" ", ""); //substituir espaços

        String password = passwordFromUser2.getText().toString();
        password = password.replaceAll(" ", "");

        String minTemp = minTempFromUser2.getText().toString();
        minTemp = minTemp.replaceAll(",", ".");
        String maxTemp = maxTempFromUser2.getText().toString();
        maxTemp = maxTemp.replaceAll(",", ".");
        String WBstatus = WBstatusFromUser2.getText().toString(); //1:activa ou 0:desligada

        new addNewUser().execute(username, password, minTemp, maxTemp, WBstatus); // verificar se houve erro, ie, se estão vazios

        while(!go){ //esperar
        }

        if(!error.isEmpty()){ // se está vazio
            findViewById(R.id.wrongCredentials2).setVisibility(View.VISIBLE);
            error = ""; // por a string em vazio
            go = false;

        }else{
            Intent intent = new Intent(this, DisplayApp.class);
            error = "";
            go = false;
            intent.putExtra("username", username);  // juntar a string
            startActivity(intent);
        }

}
    public class addNewUser extends AsyncTask<String,String,String> {
        String nextActivity = "";
        @Override
        protected String doInBackground(String... arg0) {

            try {
                String username = arg0[0].replaceAll("[^a-zA-Z0-9]+", "");
                String password = arg0[1].replaceAll("[^a-zA-Z0-9]+", "");
                String minTemp = arg0[2].replaceAll("[^a-zA-Z0-9]+", "");
                String maxTemp = arg0[3].replaceAll("[^a-zA-Z0-9]+", "");
                String WBstatus = arg0[4].replaceAll("[^a-zA-Z0-9]+", "");

                String link = "http://web.ist.utl.pt/~ist425319/register.php?username=" + username+ "&password="+ password + "&minTemp=" + minTemp+ "&maxTemp=" + maxTemp + "&WBdefault=" + WBstatus;
                URL url = new URL(link);

                HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();
                urlConnection.setRequestMethod("GET");
                urlConnection.setDoInput(true);
                urlConnection.connect();

                InputStream response = urlConnection.getInputStream();
                JSONObject json = convertStreamToJSON(response);

                if(json.getBoolean("error")){
                    error = json.getString("message");
                    go = true;
                }else{
                    error = "";
                    go = true;
                }

                urlConnection.disconnect();


            } catch (IOException e) {
                e.printStackTrace();

            } catch (JSONException e) {
                e.printStackTrace();
            }
            return this.nextActivity;
        }

    }

    private JSONObject convertStreamToJSON(InputStream is) throws JSONException {

        BufferedReader reader = new BufferedReader(new InputStreamReader(is));
        StringBuilder sb = new StringBuilder();

        String line = null;
        try {
            while ((line = reader.readLine()) != null) {
                sb.append(line + "\n");
            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                is.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        String str = sb.toString();
        json = new JSONObject(str);
        return json;
    }



}
