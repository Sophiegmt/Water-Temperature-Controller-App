package com.example.rmsf;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;


public class SettingsActivity  extends AppCompatActivity {
    Button button;
    TextView MinT;
    TextView MaxT;
    TextView WBstatus;
    String WBdefault = "";

    String error = "";
    Boolean go = false;
    JSONObject json = null;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);
    }

    public void mint(View view) {
        button = findViewById(R.id.SaveChangesbutton);
        button.setVisibility(View.VISIBLE);
    }

    public void maxt(View view) {
        button = findViewById(R.id.SaveChangesbutton);
        button.setVisibility(View.VISIBLE);
    }

    public void wb(View view) {
        button = findViewById(R.id.SaveChangesbutton);
        button.setVisibility(View.VISIBLE);
    }

    public void button(View view) {
        MinT = findViewById(R.id.minTemp);
        MaxT = findViewById(R.id.maxTemp);
        WBstatus = findViewById(R.id.WBstatus);
        button = findViewById(R.id.SaveChangesbutton);
        button.setVisibility(View.INVISIBLE);

        String username = getUsername();  // juntar a string
        System.out.println(username);
        String minTemp = MinT.getText().toString();
        minTemp = minTemp.replaceAll(" ", "");
        minTemp = minTemp.replaceAll(",", ".");
        String maxTemp = MaxT.getText().toString();
        maxTemp = maxTemp.replaceAll(" ", "");
        maxTemp = maxTemp.replaceAll(",", ".");
        WBdefault = WBstatus.getText().toString();
        WBdefault = WBdefault.replaceAll(" ", "");


        new changeSettings().execute(username, minTemp, maxTemp, WBdefault);

        while (!go) { //esperar
        }

        if (!error.isEmpty()) { // se está vazio
            error = ""; // por a string em vazio
            go = false;

        } else {
            Intent intent = new Intent(this, DisplayApp.class);
            error = "";
            go = true;
            intent.putExtra("username", username);  // juntar a string
            startActivity(intent);
        }


    }

    // substituir novos dados na base de dados


    public class changeSettings extends AsyncTask<String, String, String> {
        String nextActivity = "";

        @Override
        protected String doInBackground(String... arg0) {

                try {
                String username = arg0[0].replaceAll("[^a-zA-Z0-9]+", "");
                String minTemp = arg0[1].replaceAll("[^a-zA-Z0-9]+", "");
                String maxTemp = arg0[2].replaceAll("[^a-zA-Z0-9]+", "");
                String WBstatus = WBdefault.replaceAll("[^a-zA-Z0-9]+", "");
                System.out.println(minTemp);
                System.out.println(maxTemp);
                System.out.println(WBstatus);
                String link = "http://web.ist.utl.pt/~ist425319/updateTsW.php?username=" + username + "&newTmin=" + minTemp + "&newTmax=" + maxTemp + "&newWd=" + WBstatus;
                URL url = new URL(link);

                HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();
                urlConnection.setRequestMethod("GET");
                urlConnection.setDoInput(true);
                urlConnection.connect();

                InputStream response = urlConnection.getInputStream();
                JSONObject json = convertStreamToJSON(response);

                if(json.getBoolean("error")){
                    error = json.getString("message");
                    go = true;
                }else{
                    error = "";
                    go = true;
                }

                urlConnection.disconnect();


            } catch (JSONException e) {
                e.printStackTrace();
            } catch (IOException e) {
                    e.printStackTrace();
            }
          return this.nextActivity;
        }

    }

    public String getUsername() {
        String username = "";
        username = getIntent().getStringExtra("username");
        return username;
    }


    private JSONObject convertStreamToJSON(InputStream is) throws JSONException {

        BufferedReader reader = new BufferedReader(new InputStreamReader(is));
        StringBuilder sb = new StringBuilder();

        String line = null;
        try {
            while ((line = reader.readLine()) != null) {
                sb.append(line + "\n");
            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                is.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        String str = sb.toString();
        System.out.println(str);
        json = new JSONObject(str);
        return json;
    }

}

